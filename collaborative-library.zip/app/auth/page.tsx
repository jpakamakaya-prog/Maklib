'use client'

import { FormEvent, useEffect, useState } from 'react'
import { ArrowLeft, CheckCircle2, LockKeyhole, Mail, ShieldCheck } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase/client'

export default function AuthPage() {
  const router = useRouter()
  const [mode, setMode] = useState<'login' | 'signup'>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmation, setConfirmation] = useState('')
  const [message, setMessage] = useState<{ type: 'error' | 'success'; text: string } | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const error = new URLSearchParams(window.location.search).get('error')
    if (error === 'confirmation_failed') setMessage({ type: 'error', text: 'Le lien de confirmation est invalide ou a expiré. Demandez un nouvel e-mail.' })
    if (error === 'missing_code') setMessage({ type: 'error', text: 'Le lien de confirmation est incomplet. Demandez un nouvel e-mail.' })
    if (error === 'service_unavailable') setMessage({ type: 'error', text: 'Le service de connexion est momentanément indisponible.' })
  }, [])

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setMessage(null)
    if (!supabase) return setMessage({ type: 'error', text: 'Le service de connexion est momentanément indisponible.' })
    if (password.length < 6) return setMessage({ type: 'error', text: 'Le mot de passe doit contenir au moins 6 caractères.' })
    if (mode === 'signup' && password !== confirmation) return setMessage({ type: 'error', text: 'Les mots de passe ne correspondent pas.' })
    setLoading(true)
    try {
      if (mode === 'login') {
        const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim().toLowerCase(), password })
        if (error) {
          const detail = error.message.toLowerCase()
          setMessage({ type: 'error', text: detail.includes('confirm') || detail.includes('verified') ? 'Veuillez confirmer votre adresse e-mail avant de vous connecter.' : 'Email ou mot de passe incorrect.' })
          return
        }
        if (!data.user?.email_confirmed_at) return setMessage({ type: 'error', text: 'Veuillez confirmer votre adresse e-mail avant de vous connecter.' })
        router.push('/')
        router.refresh()
      } else {
        const { data, error } = await supabase.auth.signUp({ email: email.trim().toLowerCase(), password, options: { emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL ?? `${window.location.origin}/auth/callback` } })
        if (error) {
          const detail = error.message.toLowerCase()
          setMessage({ type: 'error', text: detail.includes('already') ? 'Cette adresse e-mail est déjà utilisée.' : detail.includes('password') ? 'Le mot de passe doit contenir au moins 6 caractères.' : 'Inscription impossible. Vérifiez votre adresse e-mail.' })
          return
        }
        if (data.session) { router.push('/'); router.refresh() }
        else setMessage({ type: 'success', text: 'Un e-mail de confirmation a été envoyé à votre adresse. Vérifiez votre boîte de réception pour activer votre compte.' })
      }
    } finally { setLoading(false) }
  }

  return <main className="flex min-h-screen items-center justify-center bg-background px-5 py-10"><div className="w-full max-w-5xl overflow-hidden rounded-[2rem] border border-border bg-card shadow-2xl shadow-primary/10 lg:grid lg:grid-cols-[0.9fr_1.1fr]"><section className="hidden bg-gradient-to-br from-primary to-indigo-700 p-10 text-primary-foreground lg:flex lg:flex-col lg:justify-between"><div><button onClick={() => router.push('/')} className="flex items-center gap-2 text-sm opacity-80 hover:opacity-100"><ArrowLeft className="size-4" /> Retour à la bibliothèque</button><div className="mt-24"><div className="flex size-12 items-center justify-center rounded-2xl bg-primary-foreground/15"><ShieldCheck /></div><h1 className="mt-6 font-serif text-5xl font-semibold leading-tight">Votre bibliothèque,<br />toujours avec vous.</h1><p className="mt-5 max-w-sm leading-7 text-primary-foreground/75">Rejoignez une communauté qui partage ses livres et documents avec simplicité.</p></div></div><p className="text-sm text-primary-foreground/60">MakLib · Lecture collaborative</p></section><section className="p-6 sm:p-10 lg:p-14"><button onClick={() => router.push('/')} className="mb-8 flex items-center gap-2 text-sm text-muted-foreground lg:hidden"><ArrowLeft className="size-4" /> Bibliothèque</button><div className="flex items-center gap-2 text-primary"><LockKeyhole className="size-5" /><span className="text-sm font-semibold">Espace sécurisé</span></div><h2 className="mt-5 font-serif text-4xl font-semibold tracking-tight">{mode === 'login' ? 'Bon retour.' : 'Créer un compte.'}</h2><p className="mt-3 text-sm leading-6 text-muted-foreground">{mode === 'login' ? 'Connectez-vous pour retrouver vos favoris et partager vos lectures.' : 'Créez votre espace personnel en quelques secondes.'}</p><div className="mt-8 grid grid-cols-2 rounded-xl bg-muted p-1"><button onClick={() => { setMode('login'); setMessage(null) }} className={`rounded-lg px-3 py-3 text-sm font-medium ${mode === 'login' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground'}`}>Connexion</button><button onClick={() => { setMode('signup'); setMessage(null) }} className={`rounded-lg px-3 py-3 text-sm font-medium ${mode === 'signup' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground'}`}>Inscription</button></div><form onSubmit={submit} className="mt-8 space-y-5"><label className="block text-sm font-medium">Email<div className="mt-2 flex items-center gap-3 rounded-xl border border-input bg-background px-4"><Mail className="size-5 text-muted-foreground" /><input required type="email" value={email} onChange={e => setEmail(e.target.value)} className="min-w-0 flex-1 bg-transparent py-4 outline-none" placeholder="vous@exemple.com" /></div></label><label className="block text-sm font-medium">Mot de passe<div className="mt-2 flex items-center gap-3 rounded-xl border border-input bg-background px-4"><LockKeyhole className="size-5 text-muted-foreground" /><input required type="password" value={password} onChange={e => setPassword(e.target.value)} className="min-w-0 flex-1 bg-transparent py-4 outline-none" placeholder="6 caractères minimum" /></div></label>{mode === 'login' ? <button type="button" className="text-sm text-primary hover:underline">Mot de passe oublié ?</button> : <label className="block text-sm font-medium">Confirmer le mot de passe<div className="mt-2 flex items-center gap-3 rounded-xl border border-input bg-background px-4"><LockKeyhole className="size-5 text-muted-foreground" /><input required type="password" value={confirmation} onChange={e => setConfirmation(e.target.value)} className="min-w-0 flex-1 bg-transparent py-4 outline-none" placeholder="Répétez votre mot de passe" /></div></label>}{message && <div role="alert" className={`flex gap-3 rounded-xl p-4 text-sm leading-6 ${message.type === 'success' ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' : 'bg-rose-500/10 text-rose-700 dark:text-rose-300'}`}>{message.type === 'success' && <CheckCircle2 className="mt-0.5 size-5 shrink-0" />}{message.text}</div>}<button disabled={loading} type="submit" className="w-full rounded-xl bg-primary px-5 py-4 font-medium text-primary-foreground shadow-lg shadow-primary/20 disabled:cursor-not-allowed disabled:opacity-60">{loading ? 'Traitement en cours…' : mode === 'login' ? 'Se connecter' : 'Créer mon compte'}</button></form></section></div></main>
}
